import ActivityKit

struct TimerAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var progress: Double
        var status: String
    }
    var title: String
}
