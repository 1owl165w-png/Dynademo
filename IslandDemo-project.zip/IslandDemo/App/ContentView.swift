import SwiftUI
import ActivityKit

@MainActor
final class LiveActivityManager: ObservableObject {
    private var activity: Activity<TimerAttributes>?
    @Published var message = ""

    func start() {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            message = "Live Activities вимкнено в Налаштуваннях"
            return
        }
        let state = TimerAttributes.ContentState(progress: 0, status: "Старт")
        do {
            activity = try Activity.request(
                attributes: TimerAttributes(title: "Завантаження файлу"),
                content: .init(state: state, staleDate: nil)
            )
            message = "Запущено"
        } catch {
            message = "Помилка: \(error.localizedDescription)"
        }
    }

    func update(progress: Double, status: String) async {
        let state = TimerAttributes.ContentState(progress: progress, status: status)
        await activity?.update(.init(state: state, staleDate: nil))
    }

    func end() async {
        let state = TimerAttributes.ContentState(progress: 1, status: "Готово")
        await activity?.end(.init(state: state, staleDate: nil), dismissalPolicy: .default)
        activity = nil
        message = "Завершено"
    }
}

struct ContentView: View {
    @StateObject private var manager = LiveActivityManager()

    var body: some View {
        VStack(spacing: 16) {
            Text("Dynamic Island demo").font(.title2)
            Button("Запустити") { manager.start() }
            Button("50%") { Task { await manager.update(progress: 0.5, status: "Половина") } }
            Button("90%") { Task { await manager.update(progress: 0.9, status: "Майже") } }
            Button("Завершити") { Task { await manager.end() } }
            Text(manager.message).font(.footnote).foregroundStyle(.secondary)
        }
        .buttonStyle(.borderedProminent)
        .padding()
    }
}
