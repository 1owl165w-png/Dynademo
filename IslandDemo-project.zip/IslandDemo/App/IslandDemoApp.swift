import SwiftUI

@main
struct IslandDemoApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
